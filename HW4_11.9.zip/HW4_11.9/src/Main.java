import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random rdn = new Random();
        int day = rdn.nextInt(1, 10);
        System.out.println(day);
        System.out.println(day == 1 ? "Понедельник" : day == 2 ? "Вторник" : day == 3 ? "Среда" : day == 4 ? "Четверг" : day == 5 ? "Пятница" : day == 6 ? "Суббота" : day == 7 ?"Воскресенье" : "такого дня недели нет");
    }
}
//Дан (введён или сгенерирован) номер дня недели. Выведите название дня
//недели. Если номер дня введён некорректно, то выведите соответствующее
//сообщение и завершите программу