import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите число 1");
        int a = scn.nextInt();
        System.out.println("Введите число 2");
        int b = scn.nextInt();
        System.out.printf("сколько будет %d на %d?", a, b);
        System.out.println("");
        int c = scn.nextInt();
        int d = a * b;
        if (c == d) {
            System.out.println("ответ правильный") ;
        } else if (c != d) {
            System.out.println("ответ не правильный");
            System.out.printf("правильный ответ %d", d);
        }
    }
}

//№2
//Необходимо написать программу, которая проверяет пользователя на знание
//таблицы умножения. Пользователь сам вводит два целых однозначных числа.
//Программа задаёт вопрос: результат умножения первого числа на второе.
//Пользователь должен ввести ответ и увидеть на экране правильно он ответил
//или нет. Если пользователь ответил неправильно, то программа должна
//показать правильный ответ.