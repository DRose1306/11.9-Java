import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();
        int m = rnd.nextInt(0,20);
        System.out.println(m);
        int n = rnd.nextInt(0,20);
        System.out.println(n);
        if (Math.abs(m-10) < Math.abs(n-10)) {
            System.out.println(m);
        }else System.out.println(n);
    }
}
//№1
//Создать программу, выводящую на экран ближайшее к 10 из двух чисел,
//записанных в переменные m и n.
//Числа могут быть, как целочисленные, так и дробные.
//Например :
//ввод : m=10.5, n=10.45
//вывод: Число 10.45 ближе к 10.
