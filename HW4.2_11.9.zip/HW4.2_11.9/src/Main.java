import java.time.DayOfWeek;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();
        int day = rnd.nextInt(1,9);
        System.out.println(day);
        String weekDay = switch (day){
            case 1 -> "Monday";
            case 2 -> "Tuesday";
            case 3 -> "Wednesday";
            case 4 -> "Thursday";
            case 5 -> "Friday";
            case 6 -> "Saturday";
            case 7 -> "Sunday";
            default -> "такого пальца нет";
        };
        System.out.println(weekDay);
    }
}
///Дан (введён или сгенерирован) номер дня недели. Выведите название дня
////недели. Если номер дня введён некорректно, то выведите соответствующее
////сообщение и завершите программу